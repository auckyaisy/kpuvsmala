// embeded two forks of

//Ibe's Pen Background Noise - Canvas.
//https://codepen.io/IbeVanmeenen/full/vZzgvg/

//and

// Diaco M.Lotfollahi's Pen GSAP Old Movie Style.
//https://codepen.io/MAW/full/rxqqQG/